package com.example.vijay.android_json;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

public class RogerAdapter extends RecyclerView.Adapter<RogerAdapter.MyViewHolder> {

    private LayoutInflater inflater;
    private ArrayList<RogerModel> rogerModelArrayList;

    public RogerAdapter(Context ctx, ArrayList<RogerModel> rogerModelArrayList){

        inflater = LayoutInflater.from(ctx);
        this.rogerModelArrayList = rogerModelArrayList;
    }

    @Override
    public RogerAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = inflater.inflate(R.layout.rv_item, parent, false);
        MyViewHolder holder = new MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(RogerAdapter.MyViewHolder holder, int position) {

        Picasso.get().load(rogerModelArrayList.get(position).getImgURL()).into(holder.iv);
        holder.name.setText(rogerModelArrayList.get(position).getName());
        holder.category.setText(rogerModelArrayList.get(position).getCategory());
        holder.summary.setText(rogerModelArrayList.get(position).getSummary());
    }

    @Override
    public int getItemCount() {
        return rogerModelArrayList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView category, name, summary;
        ImageView iv;

        public MyViewHolder(View itemView) {
            super(itemView);

            category = (TextView) itemView.findViewById(R.id.category);
            name = (TextView) itemView.findViewById(R.id.name);
            summary = (TextView) itemView.findViewById(R.id.summary);
            iv = (ImageView) itemView.findViewById(R.id.iv);
        }

    }
}