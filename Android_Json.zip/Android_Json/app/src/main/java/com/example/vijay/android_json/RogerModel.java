package com.example.vijay.android_json;

import org.json.JSONArray;

public class RogerModel {
    private String name, country, city, imgURL,Summary;

    public String getImgURL(){
        return imgURL;
    }

    public void setImgURL(String imgURL){
        this.imgURL = imgURL;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return country;
    }

    public void setCategory(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
    public void setSummary(String Summary) {
        this.Summary = Summary;
    }
    public String getSummary() {
        return Summary;
    }

}
